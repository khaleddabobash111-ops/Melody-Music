import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../../core/l10n/strings.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/providers.dart';
import '../../shared/flows.dart';
import '../../shared/widgets.dart';

@immutable
class SavedYouTubeItem {
  const SavedYouTubeItem({
    required this.id,
    required this.title,
    required this.originalUrl,
    required this.embedUrl,
    required this.isPlaylist,
    this.thumbnailUrl,
  });

  final String id;
  final String title;
  final String originalUrl;
  final String embedUrl;
  final bool isPlaylist;
  final String? thumbnailUrl;

  Map<String, Object?> toJson() => {
        'id': id,
        'title': title,
        'originalUrl': originalUrl,
        'embedUrl': embedUrl,
        'isPlaylist': isPlaylist,
        'thumbnailUrl': thumbnailUrl,
      };

  factory SavedYouTubeItem.fromJson(Map<String, dynamic> m) => SavedYouTubeItem(
        id: m['id'] as String,
        title: m['title'] as String,
        originalUrl: m['originalUrl'] as String,
        embedUrl: m['embedUrl'] as String,
        isPlaylist: (m['isPlaylist'] as bool?) ?? false,
        thumbnailUrl: m['thumbnailUrl'] as String?,
      );
}

class YouTubeListNotifier extends Notifier<List<SavedYouTubeItem>> {
  static const _key = 'youtube_saved_playlists_v1';

  @override
  List<SavedYouTubeItem> build() {
    final raw = ref.read(prefsProvider).getString(_key);
    if (raw == null) return const [];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list.map((e) => SavedYouTubeItem.fromJson(e as Map<String, dynamic>)).toList();
    } catch (_) {
      return const [];
    }
  }

  void _save(List<SavedYouTubeItem> items) {
    state = items;
    ref.read(prefsProvider).setString(_key, jsonEncode(items.map((e) => e.toJson()).toList()));
  }

  bool addFromUrl(String rawUrl, {String? customTitle}) {
    final parsed = parseYouTubeUrl(rawUrl);
    if (parsed == null) return false;
    final title = (customTitle?.trim().isNotEmpty ?? false) ? customTitle!.trim() : parsed.title;
    final item = SavedYouTubeItem(
      id: '${DateTime.now().microsecondsSinceEpoch}',
      title: title,
      originalUrl: rawUrl.trim(),
      embedUrl: parsed.embedUrl,
      isPlaylist: parsed.isPlaylist,
      thumbnailUrl: parsed.thumbnailUrl,
    );
    _save([item, ...state]);
    return true;
  }

  void remove(String id) {
    _save(state.where((e) => e.id != id).toList());
  }

  static SavedYouTubeItem? parseYouTubeUrl(String raw) {
    final uri = Uri.tryParse(raw.trim());
    if (uri == null || (uri.scheme != 'https' && uri.scheme != 'http')) return null;
    final host = uri.host.toLowerCase();
    final isYt = host == 'youtube.com' ||
        host.endsWith('.youtube.com') ||
        host == 'youtu.be';
    if (!isYt) return null;

    final listId = uri.queryParameters['list'];
    String? videoId = uri.queryParameters['v'];
    if (videoId == null && host == 'youtu.be' && uri.pathSegments.isNotEmpty) {
      videoId = uri.pathSegments.first;
    } else if (videoId == null && uri.pathSegments.length >= 2 && (uri.pathSegments.first == 'shorts' || uri.pathSegments.first == 'embed')) {
      videoId = uri.pathSegments[1];
    }

    if (listId != null && listId.isNotEmpty) {
      return SavedYouTubeItem(
        id: listId,
        title: 'قائمة تشغيل يوتيوب',
        originalUrl: raw.trim(),
        embedUrl: 'https://www.youtube.com/embed/videoseries?list=$listId&autoplay=1&rel=0',
        isPlaylist: true,
        thumbnailUrl: videoId != null && videoId.isNotEmpty ? 'https://i.ytimg.com/vi/$videoId/hqdefault.jpg' : null,
      );
    }

    if (videoId != null && videoId.isNotEmpty) {
      return SavedYouTubeItem(
        id: videoId,
        title: 'فيديو يوتيوب',
        originalUrl: raw.trim(),
        embedUrl: 'https://www.youtube.com/embed/$videoId?autoplay=1&rel=0',
        isPlaylist: false,
        thumbnailUrl: 'https://i.ytimg.com/vi/$videoId/hqdefault.jpg',
      );
    }
    return null;
  }
}

final youtubeListProvider = NotifierProvider<YouTubeListNotifier, List<SavedYouTubeItem>>(YouTubeListNotifier.new);

class YouTubePlaylistsPage extends ConsumerWidget {
  const YouTubePlaylistsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = S.of(context);
    final items = ref.watch(youtubeListProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(s.ar ? 'قوائم يوتيوب' : 'YouTube Playlists'),
        actions: [
          IconButton(
            tooltip: s.importLink,
            icon: const Icon(Icons.download_rounded),
            onPressed: () => importLinkFlow(context, ref),
          ),
          IconButton(
            tooltip: s.ar ? 'إضافة قائمة يوتيوب' : 'Add YouTube playlist',
            icon: const Icon(Icons.add_rounded),
            onPressed: () => _showAddDialog(context, ref),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              color: AppColors.brand.withOpacity(.14),
              border: Border.all(color: AppColors.brand.withOpacity(.35)),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.ondemand_video_rounded, color: AppColors.brand),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    s.ar
                        ? 'أضف أي رابط قائمة تشغيل أو فيديو من يوتيوب لتشغيله ومشاهدته داخل التطبيق (يتطلب إنترنت). أما الأغاني والفيديوهات المحفوظة من هاتفك أو عبر رابط مباشر فتعمل 100% بدون نت في تبويب المكتبة.'
                        : 'Save any YouTube playlist or video link to watch inside Melody Music (requires internet). Songs and videos imported from your phone or direct links work 100% offline in Library.',
                    style: const TextStyle(fontSize: 12.5, height: 1.5, color: AppColors.textSecondary),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          if (items.isEmpty)
            EmptyState(
              icon: Icons.playlist_play_rounded,
              title: s.ar ? 'لا توجد قوائم يوتيوب بعد' : 'No YouTube playlists yet',
              body: s.ar
                  ? 'الصق رابط قائمة تشغيل أو أغنية من يوتيوب لفتحها ومشاهدتها هنا.'
                  : 'Paste a YouTube playlist or video link to save and play it here.',
              actionLabel: s.ar ? 'إضافة رابط يوتيوب' : 'Add YouTube link',
              onAction: () => _showAddDialog(context, ref),
            )
          else
            for (final item in items)
              Card(
                margin: const EdgeInsets.only(bottom: 10),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: item.thumbnailUrl != null
                        ? Image.network(
                            item.thumbnailUrl!,
                            width: 68,
                            height: 50,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => _ytFallback(item.isPlaylist),
                          )
                        : _ytFallback(item.isPlaylist),
                  ),
                  title: Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(
                    item.isPlaylist ? (s.ar ? 'قائمة تشغيل يوتيوب' : 'YouTube Playlist') : (s.ar ? 'فيديو يوتيوب' : 'YouTube Video'),
                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline_rounded),
                    onPressed: () => ref.read(youtubeListProvider.notifier).remove(item.id),
                  ),
                  onTap: () {
                    ref.read(audioHandlerProvider).pause();
                    Navigator.push(
                      context,
                      MaterialPageRoute<void>(builder: (_) => _YouTubePlayerScreen(item: item)),
                    );
                  },
                ),
              ),
        ],
      ),
    );
  }

  Widget _ytFallback(bool isPlaylist) => Container(
        width: 68,
        height: 50,
        color: Colors.redAccent.withOpacity(.18),
        child: Icon(isPlaylist ? Icons.playlist_play_rounded : Icons.play_circle_fill_rounded, color: Colors.redAccent),
      );

  Future<void> _showAddDialog(BuildContext context, WidgetRef ref) async {
    final s = S.of(context);
    final urlCtrl = TextEditingController();
    final titleCtrl = TextEditingController();
    String? error;

    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          title: Text(s.ar ? 'إضافة قائمة أو فيديو يوتيوب' : 'Add YouTube Playlist / Video'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleCtrl,
                decoration: InputDecoration(
                  labelText: s.ar ? 'الاسم (اختياري)' : 'Title (optional)',
                  hintText: s.ar ? 'مثال: أغاني السفر' : 'e.g. Road Trip Mix',
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: urlCtrl,
                keyboardType: TextInputType.url,
                textDirection: TextDirection.ltr,
                decoration: const InputDecoration(
                  labelText: 'YouTube URL',
                  hintText: 'https://www.youtube.com/playlist?list=...',
                ),
              ),
              if (error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Text(error!, style: const TextStyle(color: AppColors.error, fontSize: 12.5)),
                ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: Text(s.cancel)),
            FilledButton(
              onPressed: () {
                final ok = ref.read(youtubeListProvider.notifier).addFromUrl(urlCtrl.text, customTitle: titleCtrl.text);
                if (!ok) {
                  setState(() => error = s.ar ? 'الرجاء إدخال رابط يوتيوب صحيح (فيديو أو قائمة تشغيل).' : 'Please enter a valid YouTube playlist or video link.');
                  return;
                }
                Navigator.pop(ctx);
                toast(context, s.ar ? 'تمت إضافة الرابط بنجاح' : 'YouTube link saved');
              },
              child: Text(s.create),
            ),
          ],
        ),
      ),
    );
  }
}

class _YouTubePlayerScreen extends StatefulWidget {
  const _YouTubePlayerScreen({required this.item});
  final SavedYouTubeItem item;

  @override
  State<_YouTubePlayerScreen> createState() => _YouTubePlayerScreenState();
}

class _YouTubePlayerScreenState extends State<_YouTubePlayerScreen> {
  late final WebViewController _controller;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (_) {
          if (mounted) setState(() => _loading = false);
        },
      ))
      ..loadRequest(Uri.parse(widget.item.embedUrl));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(widget.item.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            tooltip: 'Reload',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () => _controller.reload(),
          ),
        ],
      ),
      body: Stack(
        children: [
          WebViewWidget(controller: _controller),
          if (_loading) const Center(child: CircularProgressIndicator()),
        ],
      ),
    );
  }
}
