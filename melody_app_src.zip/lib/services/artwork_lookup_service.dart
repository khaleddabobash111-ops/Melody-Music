import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;

class ArtworkLookupResult {
  const ArtworkLookupResult({
    this.artworkPath,
    this.artist,
    this.album,
  });

  final String? artworkPath;
  final String? artist;
  final String? album;
}

/// يبحث تلقائيًا عن صورة الغلاف واسم الفنان/الألبوم عبر واجهة iTunes العامة
/// ويحفظ الصورة محليًا على الهاتف لتعمل بدون إنترنت لاحقًا.
class ArtworkLookupService {
  static String cleanTerm(String raw) {
    var s = raw
        .replaceAll(RegExp(r'^\s*\d+[\.\-\)\s]+'), '')
        .replaceAll(RegExp(r'\([^)]*(official|video|audio|lyric|lyrics|hd|hq|4k|mv|clip|remix|kbps|mp3)[^)]*\)', caseSensitive: false), ' ')
        .replaceAll(RegExp(r'\[[^\]]*(official|video|audio|lyric|lyrics|hd|hq|4k|mv|clip|kbps|mp3)[^\]]*\]', caseSensitive: false), ' ')
        .replaceAll(RegExp(r'[_\|\-]+'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    if (s.length > 80) s = s.substring(0, 80).trim();
    return s;
  }

  static Future<ArtworkLookupResult?> lookupAndSave({
    required String title,
    required String artist,
    required String fingerprint,
    required Directory artDir,
  }) async {
    final cleanedTitle = cleanTerm(title);
    final cleanedArtist = cleanTerm(artist);
    if (cleanedTitle.isEmpty) return null;

    final queries = <String>[
      if (cleanedArtist.isNotEmpty) '$cleanedArtist $cleanedTitle',
      cleanedTitle,
    ];

    final client = HttpClient()..connectionTimeout = const Duration(seconds: 6);
    try {
      for (final q in queries) {
        final uri = Uri.https('itunes.apple.com', '/search', {
          'term': q,
          'media': 'music',
          'entity': 'song',
          'limit': '1',
        });
        final req = await client.getUrl(uri);
        final res = await req.close().timeout(const Duration(seconds: 7));
        if (res.statusCode != 200) continue;
        final body = await res.transform(utf8.decoder).join().timeout(const Duration(seconds: 7));
        final jsonMap = jsonDecode(body) as Map<String, dynamic>;
        final results = (jsonMap['results'] as List<dynamic>?) ?? const [];
        if (results.isEmpty) continue;

        final hit = results.first as Map<String, dynamic>;
        final rawArt = (hit['artworkUrl100'] as String?) ?? (hit['artworkUrl60'] as String?);
        final foundArtist = (hit['artistName'] as String?)?.trim();
        final foundAlbum = (hit['collectionName'] as String?)?.trim();

        String? savedPath;
        if (rawArt != null && rawArt.isNotEmpty) {
          final hiRes = rawArt.replaceAll('100x100bb', '600x600bb').replaceAll('60x60bb', '600x600bb');
          final imgReq = await client.getUrl(Uri.parse(hiRes));
          final imgRes = await imgReq.close().timeout(const Duration(seconds: 8));
          if (imgRes.statusCode == 200) {
            final bytes = await consolidateHttpClientResponseBytes(imgRes).timeout(const Duration(seconds: 10));
            if (bytes.isNotEmpty) {
              final f = File(p.join(artDir.path, '$fingerprint.jpg'));
              await f.writeAsBytes(bytes, flush: true);
              savedPath = f.path;
            }
          }
        }
        if (savedPath != null || (foundArtist?.isNotEmpty ?? false)) {
          return ArtworkLookupResult(
            artworkPath: savedPath,
            artist: foundArtist,
            album: foundAlbum,
          );
        }
      }
    } catch (e) {
      debugPrint('Artwork lookup skipped: $e');
    } finally {
      client.close();
    }
    return null;
  }
}
