import 'dart:async';
import 'dart:io';
import 'package:archive/archive.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../data/models/track.dart';
import '../data/repositories/library_repository.dart';
import 'artwork_lookup_service.dart';
import 'metadata_reader.dart';

class ImportResult {
  const ImportResult({this.added = 0, this.skipped = 0, this.failed = 0, this.tracks = const []});
  final int added, skipped, failed;
  final List<Track> tracks;
}

enum LinkError { invalid, streaming, notAudio, network, duplicate }

class LinkImportException implements Exception {
  LinkImportException(this.error);
  final LinkError error;
}

class ImportService {
  ImportService(this.repo);
  final LibraryRepository repo;

  static const supportedExt = {'.mp3', '.m4a', '.aac', '.flac', '.wav', '.ogg', '.opus', '.wma'};
  static const _streamingHosts = [
    'youtube.com', 'youtu.be', 'spotify.com', 'music.apple.com', 'soundcloud.com',
    'deezer.com', 'tidal.com', 'anghami.com', 'music.amazon.com',
  ];
  static const _maxDownload = 300 * 1024 * 1024;

  Future<Directory> _dir(String name) async {
    final base = await getApplicationDocumentsDirectory();
    return Directory(p.join(base.path, name)).create(recursive: true);
  }

  /// بصمة: حجم الملف + SHA1 لأول 256KB. سريعة وكافية لمنع التكرار.
  Future<String> fingerprint(File f) async {
    final raf = await f.open();
    try {
      final len = await raf.length();
      final head = await raf.read(len < 262144 ? len : 262144);
      return sha1.convert([...head, ...len.toString().codeUnits]).toString();
    } finally {
      await raf.close();
    }
  }

  // ---------- ملفات محلية وملفات ZIP ----------
  Future<ImportResult> importFiles(List<String> paths, {bool Function()? cancelled, void Function(int done, int total)? onProgress}) async {
    var added = 0, skipped = 0, failed = 0;
    final tracks = <Track>[];
    for (var i = 0; i < paths.length; i++) {
      if (cancelled?.call() ?? false) break;
      final path = paths[i];
      try {
        if (p.extension(path).toLowerCase() == '.zip') {
          final zr = await _importZip(File(path), cancelled: cancelled);
          added += zr.added;
          skipped += zr.skipped;
          failed += zr.failed;
          tracks.addAll(zr.tracks);
        } else {
          final t = await _importOne(File(path), 'local');
          if (t == null) {
            skipped++;
          } else {
            added++;
            tracks.add(t);
          }
        }
      } catch (e) {
        debugPrint('import failed $path: $e');
        failed++;
      }
      onProgress?.call(i + 1, paths.length);
    }
    return ImportResult(added: added, skipped: skipped, failed: failed, tracks: tracks);
  }

  /// يفك ضغط ملف ZIP كامل ويستخرج كل الأغاني منه تلقائيًا داخل قائمة تشغيل باسم الملف.
  Future<ImportResult> _importZip(File zipFile, {bool Function()? cancelled}) async {
    var added = 0, skipped = 0, failed = 0;
    final tracks = <Track>[];
    final tmpDir = await getTemporaryDirectory();
    final extractDir = await Directory(p.join(tmpDir.path, 'zip_${DateTime.now().microsecondsSinceEpoch}')).create(recursive: true);
    try {
      final bytes = await zipFile.readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);
      for (final entry in archive) {
        if (cancelled?.call() ?? false) break;
        if (!entry.isFile) continue;
        final ext = p.extension(entry.name).toLowerCase();
        if (!supportedExt.contains(ext)) continue;
        final safeName = p.basename(entry.name).replaceAll(RegExp(r'[^\w\.\-\u0600-\u06FF ]'), '_');
        final extracted = File(p.join(extractDir.path, safeName));
        final content = entry.content as List<int>;
        await extracted.writeAsBytes(content, flush: true);
        try {
          final t = await _importOne(extracted, 'local');
          if (t == null) {
            skipped++;
          } else {
            added++;
            tracks.add(t);
          }
        } catch (e) {
          debugPrint('zip entry import failed ${entry.name}: $e');
          failed++;
        }
      }
      if (tracks.isNotEmpty) {
        final plName = p.basenameWithoutExtension(zipFile.path).trim();
        if (plName.isNotEmpty) {
          final plId = await repo.createPlaylist(plName);
          String? cover;
          for (final t in tracks) {
            await repo.addToPlaylist(plId, t.id);
            cover ??= t.artworkPath;
          }
          if (cover != null) await repo.setPlaylistArtwork(plId, cover);
        }
      }
    } finally {
      try {
        if (await extractDir.exists()) await extractDir.delete(recursive: true);
      } catch (_) {}
      await _cleanTemp(zipFile);
    }
    return ImportResult(added: added, skipped: skipped, failed: failed, tracks: tracks);
  }

  /// يمسح مجلدًا كاملًا على الهاتف ويستورد كل الأغاني داخله في قائمة تشغيل باسم المجلد.
  Future<ImportResult> importFolder(String dirPath, {bool Function()? cancelled}) async {
    final dir = Directory(dirPath);
    if (!await dir.exists()) return const ImportResult();
    final files = <String>[];
    await for (final entity in dir.list(recursive: true, followLinks: false)) {
      if (entity is File) {
        final ext = p.extension(entity.path).toLowerCase();
        if (supportedExt.contains(ext) || ext == '.zip') {
          files.add(entity.path);
        }
      }
    }
    if (files.isEmpty) return const ImportResult();
    final res = await importFiles(files, cancelled: cancelled);
    if (res.tracks.isNotEmpty) {
      final folderName = p.basename(dirPath).trim();
      if (folderName.isNotEmpty) {
        final plId = await repo.createPlaylist(folderName);
        String? cover;
        for (final t in res.tracks) {
          await repo.addToPlaylist(plId, t.id);
          cover ??= t.artworkPath;
        }
        if (cover != null) await repo.setPlaylistArtwork(plId, cover);
      }
    }
    return res;
  }

  /// يبحث تلقائيًا عن صورة الغلاف لأغنية موجودة في المكتبة.
  Future<Track?> fetchArtworkForTrack(Track t) async {
    final artDir = await _dir('artwork');
    final found = await ArtworkLookupService.lookupAndSave(
      title: t.title,
      artist: t.artist,
      fingerprint: t.fingerprint,
      artDir: artDir,
    );
    if (found == null) return null;
    final newArtist = t.artist.isEmpty && (found.artist?.isNotEmpty ?? false) ? found.artist! : t.artist;
    final newAlbum = t.album.isEmpty && (found.album?.isNotEmpty ?? false) ? found.album! : t.album;
    await repo.updateArtworkAndMeta(
      t.id,
      artworkPath: found.artworkPath,
      artist: newArtist,
      album: newAlbum,
    );
    return t.copyWith(
      artworkPath: found.artworkPath ?? t.artworkPath,
      artist: newArtist,
      album: newAlbum,
    );
  }

  /// null = مكرر. يرمي استثناء عند الفشل (ملف غير مدعوم/تالف).
  Future<Track?> _importOne(File src, String sourceType) async {
    final ext = p.extension(src.path).toLowerCase();
    if (!supportedExt.contains(ext)) throw const FormatException('unsupported');
    if (!await src.exists() || await src.length() == 0) throw const FormatException('empty');

    final fp = await fingerprint(src);
    if (await repo.hasFingerprint(fp)) {
      await _cleanTemp(src);
      return null;
    }
    final musicDir = await _dir('music');
    final safe = p.basename(src.path).replaceAll(RegExp(r'[^\w\.\-\u0600-\u06FF ]'), '_');
    final dest = File(p.join(musicDir.path, '${fp.substring(0, 10)}_$safe'));
    if (src.path != dest.path) await src.copy(dest.path);
    await _cleanTemp(src);

    final meta = readTrackMeta(dest);
    String? artPath;
    final artDir = await _dir('artwork');
    if (meta.artwork != null && meta.artwork!.isNotEmpty) {
      final f = File(p.join(artDir.path, '$fp.${meta.artworkExt}'));
      await f.writeAsBytes(meta.artwork!, flush: true);
      artPath = f.path;
    }
    final fallbackTitle = p.basenameWithoutExtension(src.path);
    final resolvedTitle = (meta.title?.trim().isNotEmpty ?? false) ? meta.title!.trim() : fallbackTitle;
    var resolvedArtist = meta.artist?.trim() ?? '';
    var resolvedAlbum = meta.album?.trim() ?? '';

    // إذا لم يحتوي الملف على صورة غلاف مدمجة، نحاول جلبها تلقائيًا وحفظها محليًا
    if (artPath == null) {
      final looked = await ArtworkLookupService.lookupAndSave(
        title: resolvedTitle,
        artist: resolvedArtist,
        fingerprint: fp,
        artDir: artDir,
      );
      if (looked != null) {
        artPath = looked.artworkPath;
        if (resolvedArtist.isEmpty && (looked.artist?.isNotEmpty ?? false)) resolvedArtist = looked.artist!;
        if (resolvedAlbum.isEmpty && (looked.album?.isNotEmpty ?? false)) resolvedAlbum = looked.album!;
      }
    }

    final track = Track(
      id: fp,
      title: resolvedTitle,
      artist: resolvedArtist,
      album: resolvedAlbum,
      albumArtist: meta.albumArtist,
      trackNumber: meta.trackNumber,
      durationMs: meta.durationMs,
      path: dest.path,
      artworkPath: artPath,
      dateAdded: DateTime.now().millisecondsSinceEpoch,
      fingerprint: fp,
      sourceType: sourceType,
    );
    final ok = await repo.insertTrack(track);
    if (!ok) {
      if (await dest.exists()) await dest.delete();
      return null;
    }
    return track;
  }

  Future<void> _cleanTemp(File f) async {
    try {
      final tmp = (await getTemporaryDirectory()).path;
      if (f.path.startsWith(tmp) && await f.exists()) await f.delete();
    } catch (_) {}
  }

  // ---------- رابط مباشر ----------
  static LinkError? validateLink(String raw) {
    final uri = Uri.tryParse(raw.trim());
    if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) return LinkError.invalid;
    final host = uri.host.toLowerCase();
    if (_streamingHosts.any((h) => host == h || host.endsWith('.$h'))) return LinkError.streaming;
    return null;
  }

  /// ينزّل ملفًا صوتيًا مباشرًا فقط. لا يتجاوز أي حماية أو اشتراك.
  Future<Track> importLink(String raw, {bool Function()? cancelled}) async {
    final bad = validateLink(raw);
    if (bad != null) throw LinkImportException(bad);
    final uri = Uri.parse(raw.trim());
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 15);
    File? tmp;
    try {
      final req = await client.getUrl(uri);
      final res = await req.close().timeout(const Duration(seconds: 20));
      if (res.statusCode != 200) throw LinkImportException(LinkError.notAudio);
      final type = res.headers.contentType?.mimeType ?? '';
      var ext = p.extension(uri.path).toLowerCase();
      final looksAudio = type.startsWith('audio/') || (type == 'application/octet-stream' && supportedExt.contains(ext));
      if (!looksAudio) throw LinkImportException(LinkError.notAudio);
      if (!supportedExt.contains(ext)) ext = type.contains('mpeg') ? '.mp3' : type.contains('flac') ? '.flac' : type.contains('ogg') ? '.ogg' : '.m4a';
      if (res.contentLength > _maxDownload) throw LinkImportException(LinkError.notAudio);

      final tmpDir = await getTemporaryDirectory();
      final name = p.basenameWithoutExtension(uri.path).isEmpty ? 'track' : p.basenameWithoutExtension(uri.path);
      tmp = File(p.join(tmpDir.path, '${DateTime.now().microsecondsSinceEpoch}_$name$ext'));
      final sink = tmp.openWrite();
      var received = 0;
      try {
        await for (final chunk in res.timeout(const Duration(seconds: 30))) {
          if (cancelled?.call() ?? false) throw LinkImportException(LinkError.network);
          received += chunk.length;
          if (received > _maxDownload) throw LinkImportException(LinkError.notAudio);
          sink.add(chunk);
        }
      } finally {
        await sink.close();
      }
      final t = await _importOne(tmp, 'link');
      if (t == null) throw LinkImportException(LinkError.duplicate);
      return t;
    } on LinkImportException {
      if (tmp != null && await tmp.exists()) await tmp.delete();
      rethrow;
    } on FormatException {
      throw LinkImportException(LinkError.notAudio);
    } catch (e) {
      debugPrint('link import failed: $e');
      if (tmp != null && await tmp.exists()) await tmp.delete();
      throw LinkImportException(LinkError.network);
    } finally {
      client.close();
    }
  }

  /// يحذف نسخة التطبيق من الملف والغلاف (الملف الأصلي على الهاتف لا يُمس).
  Future<void> deleteFiles(Track t) async {
    for (final path in [t.path, t.artworkPath]) {
      if (path == null) continue;
      try {
        final f = File(path);
        if (await f.exists()) await f.delete();
      } catch (_) {}
    }
  }
}
