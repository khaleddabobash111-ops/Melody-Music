import 'dart:async';
import 'package:audio_service/audio_service.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'app.dart';
import 'data/database/app_database.dart';
import 'providers/providers.dart';
import 'services/audio_handler.dart';

/// runApp يُستدعى فورًا، فالإطار الأول يُرسم دائمًا (لا شاشة سوداء).
/// التهيئة الثقيلة تجري بعده، لكل خطوة مهلة، وأي فشل يظهر على الشاشة بسببه الحقيقي.
void main() {
  runZonedGuarded(() {
    WidgetsFlutterBinding.ensureInitialized();
    FlutterError.onError = (d) => debugPrint('FlutterError: ${d.exceptionAsString()}');
    runApp(const _Boot());
  }, (e, s) => debugPrint('Uncaught: $e\n$s'));
}

class _Deps {
  const _Deps(this.prefs, this.handler, this.db, this.backgroundOk);
  final SharedPreferences prefs;
  final MelodyAudioHandler handler;
  final Database db;
  final bool backgroundOk;
}

Future<T> _step<T>(String name, Future<T> Function() run, {int seconds = 15, String? hint}) async {
  debugPrint('MELODY_BOOT: بدء $name');
  try {
    final r = await run().timeout(Duration(seconds: seconds));
    debugPrint('MELODY_BOOT: تم $name');
    return r;
  } on TimeoutException {
    throw StateError('انتهت المهلة أثناء: $name${hint == null ? '' : '\n$hint'}');
  } catch (e) {
    debugPrint('MELODY_BOOT: فشل $name: $e');
    throw StateError('فشل: $name\n$e${hint == null ? '' : '\n\n$hint'}');
  }
}

class _Boot extends StatefulWidget {
  const _Boot();
  @override
  State<_Boot> createState() => _BootState();
}

class _BootState extends State<_Boot> {
  late Future<_Deps> _future = _init();

  Future<_Deps> _init() async {
    final prefs = await _step('SharedPreferences', SharedPreferences.getInstance);
    // إن فشل تفعيل خدمة الصوت الخلفية (MainActivity/Manifest ناقصان) لا نترك التطبيق أسود:
    // نشغّل المشغل مباشرة دون إشعار/تشغيل خلفي، ونُبلغ المستخدم برسالة.
    MelodyAudioHandler handler;
    var backgroundOk = true;
    try {
      handler = await _step(
        'AudioService.init',
        () => AudioService.init(
          builder: MelodyAudioHandler.new,
          config: const AudioServiceConfig(
            androidNotificationChannelId: 'com.melodymusic.app.playback',
            androidNotificationChannelName: 'Melody Music',
            androidNotificationOngoing: true,
          ),
        ),
        seconds: 10,
      );
    } catch (e) {
      debugPrint('MELODY_BOOT: التشغيل الخلفي معطّل: $e');
      handler = MelodyAudioHandler();
      backgroundOk = false;
    }
    final db = await _step('قاعدة البيانات', AppDatabase.open);
    return _Deps(prefs, handler, db, backgroundOk);
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<_Deps>(
        future: _future,
        builder: (context, snap) {
          if (snap.hasData) {
            final d = snap.data!;
            return ProviderScope(
              overrides: [
                prefsProvider.overrideWithValue(d.prefs),
                dbProvider.overrideWithValue(d.db),
                audioHandlerProvider.overrideWithValue(d.handler),
                backgroundAudioProvider.overrideWithValue(d.backgroundOk),
              ],
              child: const MelodyApp(),
            );
          }
          if (snap.hasError) {
            return _Screen(
              child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Icon(Icons.error_outline_rounded, size: 48, color: Colors.redAccent),
                const SizedBox(height: 16),
                const Text('تعذّر بدء التطبيق', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Flexible(child: SingleChildScrollView(child: SelectableText('${snap.error}'))),
                const SizedBox(height: 16),
                FilledButton(onPressed: () => setState(() => _future = _init()), child: const Text('إعادة المحاولة')),
              ]),
            );
          }
          return const _Screen(child: Center(child: CircularProgressIndicator()));
        },
      );
}

class _Screen extends StatelessWidget {
  const _Screen({required this.child});
  final Widget child;
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true),
        home: Scaffold(body: SafeArea(child: Padding(padding: const EdgeInsets.all(24), child: child))),
      );
}
