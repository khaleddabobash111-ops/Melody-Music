package com.example.melody_music

import com.ryanheise.audioservice.AudioServiceActivity

class MainActivity : AudioServiceActivity()
