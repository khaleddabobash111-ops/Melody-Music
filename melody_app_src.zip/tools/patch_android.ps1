# تهيئة android لخدمة الصوت — بدون Python. شغّله من جذر المشروع:
#   powershell -ExecutionPolicy Bypass -File tools\patch_android.ps1
# آمن لإعادة التشغيل، ويحفظ نسخة احتياطية .bak من كل ملف يعدّله.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$main = Join-Path $root 'android\app\src\main'
$manifest = Join-Path $main 'AndroidManifest.xml'
if (-not (Test-Path $manifest)) { throw "AndroidManifest.xml غير موجود في $main" }
$utf8 = New-Object System.Text.UTF8Encoding($false)

Copy-Item $manifest "$manifest.bak" -Force
$m = [System.IO.File]::ReadAllText($manifest)

if ($m -notmatch 'xmlns:tools=') {
  $m = ([regex]'<manifest ').Replace($m, '<manifest xmlns:tools="http://schemas.android.com/tools" ', 1)
}

$perms = 'android.permission.WAKE_LOCK','android.permission.FOREGROUND_SERVICE','android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK','android.permission.POST_NOTIFICATIONS'
$add = ''
foreach ($p in $perms) { if ($m -notlike "*$p*") { $add += "    <uses-permission android:name=`"$p`"/>`r`n" } }
if ($add -ne '') { $m = ([regex]'\s*<application').Replace($m, "`r`n$add    <application", 1) }

$m = ([regex]'android:label="[^"]*"').Replace($m, 'android:label="Melody Music"', 1)

if ($m -notlike '*com.ryanheise.audioservice.AudioService*') {
  $block = @'

        <service android:name="com.ryanheise.audioservice.AudioService"
            android:foregroundServiceType="mediaPlayback"
            android:exported="true" tools:ignore="Instantiatable">
            <intent-filter>
                <action android:name="android.media.browse.MediaBrowserService" />
            </intent-filter>
        </service>
        <receiver android:name="com.ryanheise.audioservice.MediaButtonReceiver"
            android:exported="true" tools:ignore="Instantiatable">
            <intent-filter>
                <action android:name="android.intent.action.MEDIA_BUTTON" />
            </intent-filter>
        </receiver>
'@
  $m = ([regex]'</application>').Replace($m, "$block`r`n    </application>", 1)
}
[System.IO.File]::WriteAllText($manifest, $m, $utf8)
Write-Host 'AndroidManifest.xml: تم'

$found = $false
Get-ChildItem -Path $main -Recurse -Include 'MainActivity.kt','MainActivity.java' | ForEach-Object {
  $found = $true
  $s = [System.IO.File]::ReadAllText($_.FullName)
  if ($s -like '*AudioServiceActivity*') { Write-Host "$($_.Name): سليم أصلًا"; return }
  Copy-Item $_.FullName "$($_.FullName).bak" -Force
  $s = $s.Replace('import io.flutter.embedding.android.FlutterActivity', 'import com.ryanheise.audioservice.AudioServiceActivity')
  $s = $s.Replace('FlutterActivity', 'AudioServiceActivity')
  [System.IO.File]::WriteAllText($_.FullName, $s, $utf8)
  Write-Host "$($_.Name): عُدّل ليرث من AudioServiceActivity"
}
if (-not $found) { Write-Warning 'لم أجد MainActivity — عدّله يدويًا ليرث من AudioServiceActivity' }
Write-Host 'انتهى. أوقف التطبيق بالكامل ثم flutter run من جديد (ليس hot restart).'
