# Melody Music — المشروع الكامل (من البداية)

## الخطوات (Windows + VS Code + Flutter في D:\Development\flutter)
1) فك الضغط، وافتح مجلد melody_music في VS Code، ثم افتح Terminal من جذر المشروع.

2) أنشئ ملفات أندرويد (مرة واحدة):
   D:\Development\flutter\bin\flutter.bat create . --org com.example --project-name melody_music --platforms android
   (com.example تجعل الحزمة com.example.melody_music وتطابق MainActivity.kt الجاهز)

3) استبدل ملفين من مجلد android_fix:
   - MainActivity.kt     ->  android\app\src\main\kotlin\com\example\melody_music\MainActivity.kt
   - AndroidManifest.xml ->  android\app\src\main\AndroidManifest.xml

4) D:\Development\flutter\bin\flutter.bat pub get
   D:\Development\flutter\bin\flutter.bat run -d 148407055M030590

5) ملف APK قابل للتثبيت بدون كمبيوتر:
   D:\Development\flutter\bin\flutter.bat build apk --release
   الناتج: build\app\outputs\flutter-apk\app-release.apk

## مشاكل معروفة قد تظهر
- خطأ compileSdk/file_picker: ارفع compileSdk إلى 36 في android\app\build.gradle.kts.
- رسالة "التشغيل في الخلفية غير مفعّل": أعد الخطوة 3 وتأكد أن namespace في build.gradle.kts = com.example.melody_music.
- الأيقونة (اختياري): dart run flutter_launcher_icons

## حالة الاختبار
الكود كُتب دون القدرة على بنائه أو تشغيله، ولم يُختبر على هاتف. أرسل أي خطأ بنصه وسأصلحه.

## أين الميزات
الرئيسية: شُغّل مؤخرًا / أُضيف مؤخرًا / المفضلة | المكتبة: 7 تبويبات | البحث | الإعدادات (مسح السجل، اللغة، السمة).
